﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Miformulario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
          
            this.BackColor = System.Drawing.Color.Red; // Cambia el color de fondo
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            // Validar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(carnetTextBox.Text) ||
                string.IsNullOrWhiteSpace(nombreTextBox.Text) ||
                string.IsNullOrWhiteSpace(seccionTextBox.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            // Saludo básico
            MessageBox.Show("Hola, " + nombreTextBox.Text + "! Bienvenido a la sección " + seccionTextBox.Text);

            // Conexión a la base de datos
            string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=UMG;Integrated Security=True;TrustServerCertificate=True;";
            string query = "SELECT * FROM tareas WHERE carnet = @carnet";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnetTextBox.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable tareas = new DataTable();

                    connection.Open();
                    adapter.Fill(tareas);

                    if (tareas.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = tareas; // Mostrar tareas
                    }
                    else
                    {
                        MessageBox.Show("No se encontraron tareas para el carnet ingresado.");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ocurrió un error al conectar con la base de datos.");
            }
        }
    }
}
