﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Miformulario.Clases
{
    public class Crud
    {
        private string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=UMG;Integrated Security=True;TrustServerCertificate=True;";

        public DataTable BuscarTareasPorCarnet(string carnet)
        {
            DataTable tareas = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "SELECT * FROM Tb_Tareas WHERE carnet = @carnet";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    connection.Open();
                    adapter.Fill(tareas);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error al conectar a la base de datos: " + ex.Message);
                }
            }

            return tareas;
        }
    }
}

