using System;
using System.Data;
using System.Data.SqlClient;

namespace SQL_1.Clases
{
    public class CrudTarea
    {
        string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=UMG;Integrated Security=True; TrustServerCertificate=True;";

        public void InsertarTarea(string carnet, string descripcion, DateTime fechaEntrega)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "INSERT INTO Tarea (carnet, descripcion, fechaEntrega) VALUES (@carnet, @descripcion, @fechaEntrega)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);
                    command.Parameters.AddWithValue("@descripcion", descripcion);
                    command.Parameters.AddWithValue("@fechaEntrega", fechaEntrega);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Tarea agregada correctamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo agregar la tarea.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                }
            }
        }

        public DataTable BuscarTareaPorCarnet(string carnet)
        {
            DataTable tareas = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "SELECT descripcion, fechaEntrega FROM Tarea WHERE carnet = @carnet";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    connection.Open();
                    adapter.Fill(tareas);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                }
            }

            return tareas;
        }
    }
}
