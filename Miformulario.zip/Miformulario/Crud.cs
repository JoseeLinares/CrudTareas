namespace SQL_1.Clases
{
    public class Crud
    {
        string connectionString = "Server=DESKTOP-K63CMO6\\SQLEXPRESS;Database=UMG;Integrated Security=True; TrustServerCertificate=True;";

        public void EliminarAlumno()
        {
            Console.WriteLine("Ingrese el carnet del alumno a eliminar:");
            string carnet = Console.ReadLine();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "DELETE FROM Tb_Alumnos WHERE carnet = @carnet";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        Console.WriteLine("Alumno eliminado exitosamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo eliminar el alumno.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                }
            }
        }

        public void ActualizarAlumno(string carnet, string nombre, string email, string seccion)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "UPDATE Tb_Alumnos SET Estudiante = @nombre, email = @correo WHERE carnet = @carnet";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@correo", email);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        Console.WriteLine("Alumno actualizado correctamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo actualizar el alumno.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                }
            }
        }

        public void MostrarAlumno()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "SELECT * FROM Tb_Alumnos WHERE seccion = 'C' ORDER BY carnet";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine($"Carnet: {reader["carnet"]}  Nombre: {reader["Estudiante"]}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                }
            }
        }

        public int AgregarAlumno(string carnet, string nombre, string email, string seccion)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "INSERT INTO Tb_Alumnos (carnet, Estudiante, seccion, email) VALUES (@carnet, @nombre, @seccion, @email)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@carnet", carnet);
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@seccion", seccion);
                    command.Parameters.AddWithValue("@email", email);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Alumno agregado correctamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo agregar el alumno.");
                    }
                    return rowsAffected;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                    return -1;
                }
            }
        }
    }
}
